<?php
    include ("conexion.php");
?>

<?php
    include ("header.php");
?>

<?php
    include ("footer.php");
?>