<?php
    include ("conexion.php");
?>

<?php
    include ("header.php");
?>

<?php
    include ("footer.php");
?>

            <?php  
                if($_POST['buscar']) ;
            {   
            ?>
            <div class="container py-5">
                <h2 class="bg-dark text-white">Resultado de la Busqueda</h2>
                        <table class="table table-bordered bg-dark text-white">
                            <thead>
                                <tr>
                                    <th>Nombre Producto</th>
                                    <th>Imagen Producto</th>
                                    <th>Precio Producto</th>
                                    <th>Categoria Producto</th>  
                                </tr>
                            </thead> 
                            <?php
                            $buscar = $_POST["palabra"];
                            $consulta = ("SELECT * FROM django_api_product WHERE name like '%$buscar%'
                                                                                or price like '%$buscar%' 
                                                                                or category_id like '%$buscar%'");
                            $consulta_mysql= mysqli_query($conectar, $consulta);
                            while($registro = mysqli_fetch_assoc($consulta_mysql)) {
                            ?> 
                            <tr>
                            <td class="estilo-tabla" align="center"><?=$registro['name']?></td>
                            <td class=”estilo-tabla” align="center"><?=$registro['url_image']?></td>
                            <td class=”estilo-tabla” align="center"><?=$registro['price']?></td>
                            <td class=”estilo-tabla” align="center"><?=$registro['category_id']?></td>
                            </tr> 
                            <?php 
                            }
                            ?>
                        </table>
                <?php
                }
                ?>
            </div>