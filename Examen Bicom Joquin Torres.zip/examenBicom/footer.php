        
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark text-info justify-content-center">
            <h1>Bienvenido al Listado de Productos</h1>
        </nav>

        <nav class="navbar navbar-expand-sm bg-dark navbar-dark justify-content-center">
            <ul class="nav nav-pills">
                    <li class="nav-item">
                    <a class="nav-link bg-dark navbar-light text-info" href="index.php">Menu Principal</a>
                    </li>
                    <div class="dropdown">
                    <button type="button" class="btn btn-dark dropdown-toggle text-info" data-toggle="dropdown">Categorias</button>
                    <div class="dropdown-menu">
                    <a id="todo" class="dropdown-item" href="listado.php">Todos los Productos</a>
                    <a id="tecno" class="dropdown-item" href="tecno.php">Tecno</a>
                    <a id="tecno" class="dropdown-item" href="electro.php">Electro</a>
                    <a id="tecno" class="dropdown-item" href="mueblesHogar.php">Muebles y Hogar</a>
                    <a id="tecno" class="dropdown-item" href="dormitorio.php">Dormitorio</a>
                    <a id="tecno" class="dropdown-item" href="deporteAventura.php">Deporte y Aventura</a>
                    </div>
                    </div>
                    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                        <form class="form-inline" action="busqueda.php" method="POST" onSubmit="return validarForm(this)">
                        <input class="form-control mr-sm-2" type="text" placeholder="Busqueda" name="palabra">
                        <button class="btn btn-success" type="submit" value="Buscar" name="buscar">Buscar</button>
                        </form>
                    </nav>
            </ul>
        </nav>
            <body background="imagen_1.jpg" class="mx-auto d-block">
</body>
</html>