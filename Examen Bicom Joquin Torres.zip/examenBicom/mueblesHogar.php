<?php
    include ("conexion.php");
?>

<?php
    include ("header.php");
?>

<?php
    include ("footer.php");
?>

<div class="container py-5">
            <h2 class="bg-dark text-white">Listado de Productos</h2>    
            <table class="table table-bordered bg-dark text-white">
        <thead>
          <tr>
              <th>Nombre Producto</th>
              <th>Imagen Producto</th>
              <th>Precio Producto</th>
              <th>Categoria Producto</th>  
          </tr>
        </thead>
        <tbody>
            <?php 
            $filtro = "SELECT * FROM django_api_product
                       WHERE category_id = 3";
              $ejecutarConsulta = mysqli_query($conectar, $filtro);
              while($fila = mysqli_fetch_array($ejecutarConsulta)) { ?>
                  <tr>
                      <td><?php echo $fila['name']?> </td>
                      <td><?php echo $fila['url_image']?> </td>
                      <td><?php echo $fila['price']?> </td>
                      <td><?php echo $fila['category_id']?> </td>
                  </tr>
            <?php }?>
        </tbody>
    </table>
</div>