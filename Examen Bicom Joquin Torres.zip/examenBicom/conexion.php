<?php

    $servidor="161.35.60.33";
    $usuario="root";
    $clave="secretbicom";
    $baseDatos="prueba";

    $conectar = mysqli_connect($servidor , $usuario , $clave , $baseDatos);
    
    if(!$conectar){
        echo"no se pudo conectar con el servidor";
    }

?>